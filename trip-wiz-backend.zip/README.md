# trip-wiz-backend

===================  xxxxxxxxxxxxxxxxxxxxx  ===================

                    The documentation is changed. Early stage documentation
                    no  longer  works.  Please  contact  the  developer for 
                    private API documentaion. 

===================  xxxxxxxxxxxxxxxxxxxxx  ===================

This is node server used to serve the TripWiz project. 

The project supports login, signup, updateUser, logout and Trip Generation APIs.
The full documentation about the project can be found at the front end of the project.

Author does not permit anyone to clone the repo and use it. This repo is made public to provide
a basic understanding of a node servers to new programmers. 

This project is not complete and is vulnerable to many attacks which is documented privately. 
please refrain from using the code for any kind of usage. 
